#!/usr/bin/env python3
"""本地完整链路测试：声纹匹配全流程"""
import os, sys, json, time

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# 添加当前目录到 path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from identify_speaker import (
    resolve_profile,
    match_speakers_in_meeting,
    apply_labels_to_turns,
    load_cam_model,
    extract_embedding,
)

print("=" * 60)
print("声纹匹配完整链路测试")
print("=" * 60)

# 1. 加载声纹
print("\n[Step 1] 加载声纹 Profile...")
try:
    profile = resolve_profile("蒸馏目标人")
    print(f"  ✓ 已加载「{profile['name']}」({len(profile['embeddings'])} 条参考)")
except Exception as e:
    print(f"  ✗ 加载失败: {e}")
    sys.exit(1)

# 2. 找测试音频
test_mp3 = None
for d in ["D:/会议记录", os.getcwd(), os.path.dirname(__file__)]:
    if os.path.isdir(d):
        for f in os.listdir(d):
            if f.lower().endswith(".mp3") and "03-18" in f:
                test_mp3 = os.path.join(d, f)
                break
    if test_mp3:
        break

if not test_mp3:
    print("  ✗ 未找到 03-18 测试音频")
    sys.exit(1)

fname = os.path.basename(test_mp3)
fsize = os.path.getsize(test_mp3) / 1024 / 1024
print(f"\n[Step 2] 测试音频: {fname} ({fsize:.1f} MB)")

# 3. 先用 FunASR 跑一遍拿到 sentence_info
print("\n[Step 3] 运行 FunASR 转录 + 说话人分离...")
from funasr import AutoModel
import torch

device = "cuda:0" if torch.cuda.is_available() else "cpu"
print(f"  设备: {device}")

t0 = time.time()
model = AutoModel(
    model="paraformer-zh",
    vad_model="fsmn-vad",
    punc_model="ct-punc",
    spk_model="cam++",
    device=device,
    disable_update=True,
)
print("  模型就绪")

result = model.generate(input=test_mp3, return_spk_res=True)
elapsed = time.time() - t0
sentence_info = result[0].get("sentence_info", [])
print(f"  ✓ 转录完成 ({elapsed:.0f}s), {len(sentence_info)} 句")

# 4. 声纹匹配
print("\n[Step 4] 声纹匹配...")
import numpy as np

t0 = time.time()
match_result = match_speakers_in_meeting(
    audio_path=test_mp3,
    sentence_info=sentence_info,
    profiles=[profile],
    threshold=0.65,
)
elapsed = time.time() - t0

print(f"\n  耗时: {elapsed:.0f}s")
print(f"  匹配结果:")
for m in match_result.get("matches", []):
    print(f"    说话人{m['spk_id']} → 「{m['name']}」相似度 {m['similarity']}")
if not match_result.get("matches"):
    print("    (无匹配)")

print(f"  说话人映射: {match_result['speaker_map']}")

# 5. 简单结论
matches = match_result.get("matches", [])
if matches:
    print(f"\n{'=' * 60}")
    print(f"✓ 测试通过！声纹匹配正常工作")
    print(f"  目标人: {matches[0]['name']}, 相似度: {matches[0]['similarity']}")
    print(f"{'=' * 60}")
else:
    print(f"\n{'=' * 60}")
    print(f"✗ 测试失败：未匹配到目标说话人")
    print(f"  请检查上方诊断信息")
    print(f"{'=' * 60}")
