#!/usr/bin/env python3
"""GPU 服务器环境诊断——逐步排查声纹提取失败的原因"""
import os, sys, subprocess

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def check(name, ok):
    print(f"  {'✓' if ok else '✗'} {name}")
    return ok

print("=" * 60)
print("GPU 服务器环境诊断")
print("=" * 60)

all_ok = True

# 1. ffmpeg
print("\n[1] ffmpeg")
try:
    r = subprocess.run(["ffmpeg", "-version"], capture_output=True)
    all_ok &= check("ffmpeg 已安装", r.returncode == 0)
except FileNotFoundError:
    all_ok &= check("ffmpeg 已安装", False)
    print("  → 请安装: apt install ffmpeg 或 yum install ffmpeg")

# 2. Python deps
print("\n[2] Python 依赖")
for pkg in ["torch", "funasr", "numpy", "modelscope"]:
    try:
        __import__(pkg)
        all_ok &= check(f"{pkg} 可用", True)
    except ImportError:
        all_ok &= check(f"{pkg} 可用", False)

# 3. CUDA
print("\n[3] CUDA / GPU")
try:
    import torch
    all_ok &= check("PyTorch 版本: " + torch.__version__, True)
    all_ok &= check(f"CUDA 可用: {torch.cuda.is_available()}", torch.cuda.is_available())
    if torch.cuda.is_available():
        print(f"  GPU: {torch.cuda.get_device_name(0)}")
        print(f"  VRAM: {torch.cuda.get_device_properties(0).total_mem / 1024**3:.1f} GB")
except Exception as e:
    all_ok &= check(f"PyTorch: {e}", False)

# 4. 声纹文件
print("\n[4] 声纹 Profile")
profile_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "speaker_profiles", "蒸馏目标人")
if os.path.isdir(profile_dir):
    all_ok &= check(f"Profile 目录存在: {profile_dir}", True)
    emb_path = os.path.join(profile_dir, "embedding.npy")
    if os.path.exists(emb_path):
        import numpy as np
        emb = np.load(emb_path)
        all_ok &= check(f"主声纹: {emb.shape} (应为 192,)", emb.shape == (192,))
    else:
        all_ok &= check("主声纹文件缺失", False)
else:
    all_ok &= check("Profile 目录存在", False)
    print(f"  寻找路径: {profile_dir}")

# 5. 测试音频切割
print("\n[5] 音频切割测试（需要有一个 MP3 文件）")
test_mp3 = None
candidates = ["/data/会议记录", os.getcwd(), os.path.dirname(__file__)]
for d in candidates:
    if os.path.isdir(d):
        for f in os.listdir(d):
            if f.lower().endswith(".mp3"):
                test_mp3 = os.path.join(d, f)
                break
    if test_mp3:
        break

if test_mp3:
    print(f"  测试文件: {os.path.basename(test_mp3)}")
    seg_path = "/tmp/test_segment.wav"
    cmd = [
        "ffmpeg", "-y",
        "-ss", "60", "-i", test_mp3,
        "-t", "5",
        "-ar", "16000", "-ac", "1",
        "-c:a", "pcm_s16le",
        seg_path,
    ]
    try:
        r = subprocess.run(cmd, capture_output=True)
        if r.returncode == 0 and os.path.getsize(seg_path) > 0:
            all_ok &= check("ffmpeg 切割音频成功", True)
            # 测试 CAM++
            print("  测试 CAM++ 声纹提取...")
            from funasr import AutoModel
            import torch
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
            m = AutoModel(model="cam++", disable_update=True, device=device)
            res = m.generate(input=seg_path)
            emb = res[0].get("spk_embedding")
            if emb is not None:
                emb = __import__('numpy').asarray(emb)
                all_ok &= check(f"CAM++ 提取成功, shape={emb.shape}", True)
            else:
                all_ok &= check("CAM++ 提取: spk_embedding 为 None", False)
        else:
            err = r.stderr.decode()[:200] if r.stderr else ""
            all_ok &= check(f"ffmpeg 切割失败: {err}", False)
    except Exception as e:
        all_ok &= check(f"测试异常: {e}", False)
else:
    print("  (跳过——未找到测试 MP3)")

# 6. 音频文件编码检查
print("\n[6] 音频文件编码（抽查）")
if test_mp3:
    try:
        r = subprocess.run([
            "ffprobe", "-v", "quiet",
            "-print_format", "json",
            "-show_format", "-show_streams",
            test_mp3
        ], capture_output=True, text=True)
        if r.returncode == 0:
            import json
            info = json.loads(r.stdout)
            for s in info.get("streams", []):
                codec = s.get("codec_name", "?")
                sr = s.get("sample_rate", "?")
                ch = s.get("channels", "?")
                print(f"  {codec}, {sr}Hz, {ch}ch")
            all_ok &= check("ffprobe 可读音频信息", True)
        else:
            all_ok &= check("ffprobe 读取失败", False)
    except Exception as e:
        all_ok &= check(f"ffprobe: {e}", False)

print("\n" + "=" * 60)
if all_ok:
    print("全部通过 ✓")
else:
    print("有问题需要修复 ✗（见上方 ✗ 项）")
print("=" * 60)
