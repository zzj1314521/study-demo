#!/bin/bash
# ============================================================
# 批量转录 + 跨会议说话人标记
# ============================================================
# 用法:
#   bash run_batch.sh                          # 默认目录
#   bash run_batch.sh /data/会议记录            # 指定音频目录
#   bash run_batch.sh /data/会议记录 /data/out cuda:7  # 指定 GPU
# ============================================================

set -e

# --- 目录配置（按需修改）---
AUDIO_DIR="${1:-/data/会议记录}"             # MP3 音频目录
OUT_TXT="${2:-${AUDIO_DIR}/文本文件}"         # TXT 输出目录
OUT_JSON="${2:-${AUDIO_DIR}/json文件}"        # JSON 输出目录
DEVICE="${3:-cuda:0}"                         # GPU 设备，默认 cuda:0
PROFILE="蒸馏目标人"                           # 要标记的目标说话人
THRESHOLD="0.65"                               # 声纹匹配阈值

echo "============================================"
echo "  FunASR 批量转录 + 说话人标记"
echo "============================================"
echo "音频目录:   $AUDIO_DIR"
echo "TXT 输出:   $OUT_TXT"
echo "JSON 输出:  $OUT_JSON"
echo "设备:       $DEVICE"
echo "目标人:     $PROFILE"
echo "阈值:       $THRESHOLD"
echo "============================================"
echo ""

python batch_transcribe.py \
    --dir "$AUDIO_DIR" \
    --speaker-profile "$PROFILE" \
    --speaker-threshold "$THRESHOLD" \
    --device "$DEVICE" \
    --txt-dir "$OUT_TXT" \
    --json-dir "$OUT_JSON" \
    --output-json \
    --skip-existing

echo ""
echo "完成！汇总文件: ${AUDIO_DIR}/_batch_summary.txt"
