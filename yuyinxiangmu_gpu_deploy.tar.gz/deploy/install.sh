#!/bin/bash
# ============================================================
# GPU 服务器环境安装脚本
# 在 Linux GPU 服务器上执行一次即可
# ============================================================

set -e

echo "=== 1. 安装 PyTorch (CUDA 12.1) ==="
pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu121

echo ""
echo "=== 2. 安装 FunASR 及相关依赖 ==="
pip install -r requirements.txt

echo ""
echo "=== 3. 验证 GPU ==="
python -c "
import torch
print(f'PyTorch: {torch.__version__}')
print(f'CUDA 可用: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'GPU: {torch.cuda.get_device_name(0)}')
    print(f'CUDA 版本: {torch.version.cuda}')
"

echo ""
echo "=== 安装完成 ==="
echo "运行批量转录: bash run_batch.sh"
